package ExceptionsP;

/**
 * Class for the empty value exception.
 * @author Juan Agust�n Lizarazo
 *
 */
public class EmptyValueException extends Exception{

	/**
	 * Constructor of the class, contains the message of the exception.
	 */
	
	public EmptyValueException() {
		
		super(" LLene todos los campos de los monomios que faltan.");
		
	}
	
	
}
