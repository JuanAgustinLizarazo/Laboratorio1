package ExceptionsP;

/**
 * Class for the space exception.
 * @author Juan Agust�n Lizarazo
 *
 */
public class SpaceValueException extends Exception{

	
	/**
	 * Constructor of the Exception that contains the message if the user writes an space in the expression.
	 */
	
	public SpaceValueException() {
		super(" Por favor no deje ning�n espacio al escribir la expres�on. ");
	}
	
}