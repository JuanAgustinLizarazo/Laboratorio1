package ExceptionsP;

/**
 * Class for the repeat monomials exception.
 * @author juana
 *
 */
public class RepeatMonomialsException extends Exception{
	
	/**
	 * Constructor of the class, that shows a message for the user ifhe/she writes a repeat monomial.
	 * @param repeat
	 */
	
	public RepeatMonomialsException(String repeat) {
		super(" El monomio "+ repeat + " se encuentra repetido. ");
	}

}
