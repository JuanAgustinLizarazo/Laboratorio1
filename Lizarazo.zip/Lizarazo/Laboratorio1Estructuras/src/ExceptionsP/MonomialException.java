package ExceptionsP;

/**
 * Class for the monomial exception.
 * @author Juan Agust�n Lizarazo
 *
 */
public class MonomialException extends Exception{

	
	/**
	 * Constructor of the Exception that contains the message if the user writes a monomial expresion.
	 */
	
	public MonomialException() {
		super(" Esta expresi�n es un monomio, por favor escriba un polinomio. ");
	}
	
}
