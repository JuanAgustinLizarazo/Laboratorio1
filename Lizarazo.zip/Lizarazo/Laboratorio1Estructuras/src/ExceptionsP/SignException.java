package ExceptionsP;

/**
 * Exception Class for the error of no defined sign.
 * @author Juan Agust�n Lizarazo
 *
 */
public class SignException extends Exception{

	
	public SignException() {
		super(" Por favor ingresar el signo o el operador correspondiente. ");
	}
}
