package application;

import java.util.Random;

import AlertsP.AlertPolynomials;
import ExceptionsP.EmptyValueException;
import ExceptionsP.NumberException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.Roots;

/**
 * Class responsable for the procedure to show the roots of the plynomials.
 * @author Juan Agust�n Lizarazo
 *
 */
public class PrincipalController {
	
	/**
	 * Relation with Root class.
	 */
	
	private Roots roots;
	
	/**
	 * ArrayList of integer that defines the coefficients.
	 */
	
	private int[] coefficients;
	/**
	 * Attribute integer for the number of monomials.
	 */
	
	private int numberMonomials;
	/**
	 * ArrayList of the values of polynomial.
	 */
	
	private TextField[] polynomialExp;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp10;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp9;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp8;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp7;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp6;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp5;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp4;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp3;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp2;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField exp1;
	
	/**
	 * Attribute textfield for the value of a monomial exponent.
	 */
	
    @FXML
    private TextField independent;
	
	/**
	 * Attribute button to generate an aleatory polynomial.
	 */
	
    @FXML
    private Button generatePolBTN;
    
    /**
     * Attribute button to erase the polynomial.
     */

    @FXML
    private Button eraseBTN;

    /**
     * Attribute button to search the roots
     */
    
    @FXML
    private Button searchBTN;
    
    /**
     * Attribute label that shows the value of the roots.
     */

    @FXML
    private Label rootValuesLbl;

    /**
     * Attribute label that shows the technique.
     */
    @FXML
    private Label techniqueLbl;

    /**
     * Method to erase the values of the polynomial.
     * @param event
     */
    
    public void initialize() {
    	
    	polynomialExp = new TextField[11];
   
    	polynomialExp[10] = exp10;
    	polynomialExp[9] = exp9;
    	polynomialExp[8] = exp8;
    	polynomialExp[7] = exp7;
    	polynomialExp[6] = exp6;
    	polynomialExp[5] = exp5;
    	polynomialExp[4] = exp4;
    	polynomialExp[3] = exp3;
    	polynomialExp[2] = exp2;
    	polynomialExp[1] = exp1;
    	polynomialExp[0] = independent;
    }
    
    /**
     * Method that erase the values of the polynomial.
     * @param event
     */
    @FXML
    void erase(ActionEvent event) {
    	for(int i = 0; i< polynomialExp.length; i++) {
    
    		polynomialExp[i].setText("");
    	}


    }

    /**
     * Method to generate an aleatory polynomial.
     * @param event
     */
    
    @FXML
    void generate(ActionEvent event) {
    	
    	for(int i = 0; i< polynomialExp.length; i++) {
    		Random random = new Random(); 
            int num = random.nextInt(199)-99;
    		polynomialExp[i].setText(""+ num);
    	}

    }
/**
 * Method to search the roots of the polynomial.
 * @param event
 */
    @FXML
    void search(ActionEvent event) {
try {
		boolean value = false;
    	for(int i = polynomialExp.length-1; i>=0 ; i--) {
    		if( polynomialExp[i].getText().length() == 0) {
    			if(value == true) {
    				if(i == 0) {
    					coefficients[0] = 0;
    				}
    				else {
    				throw new EmptyValueException();
    				}
    			}
    			else {
    				if(i == 1) {
    					throw new EmptyValueException();
    				}
    			}

    		}
    		else {
        		if(Integer.parseInt(polynomialExp[i].getText()) >-98&&Integer.parseInt(polynomialExp[i].getText()) <100) {
        			if(!value) {
        				numberMonomials = i;
        				coefficients = new int[i+1];
        				coefficients[i] = Integer.parseInt(polynomialExp[i].getText());
        				
        			}
        			value = true;
        			coefficients[i] = Integer.parseInt(polynomialExp[i].getText());
        		}
        		else {
        			throw new NumberException();
        		}
    		}
    	}
    	roots = new Roots();
    	String[] auxiliarValues = roots.evaluation(coefficients);
    	rootValuesLbl.setText(auxiliarValues[1]);
    	techniqueLbl.setText(auxiliarValues[0]);
    }
    
    catch(Exception e) {
    	AlertPolynomials alert = new AlertPolynomials(AlertType.ERROR, e.getMessage());
    	alert.show();
    }
    }
}
