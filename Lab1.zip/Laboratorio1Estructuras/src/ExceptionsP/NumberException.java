package ExceptionsP;

/**
 * Exception CLass for the error of no valid character typed.
 * @author Juan Agust�n Lizarazo
 *
 */
public class NumberException extends Exception{
	
	public NumberException() {
		super( " Por favor ingrese un coeficiente valido. Valores mayores a -99 y menores a 99. ");
	}

}
