package model;

import java.math.RoundingMode;
import java.text.DecimalFormat;

/**
 * Class that defines the value for the roots
 * @author Juan Agust�n Lizarazo
 *
 */
public class Roots {
	
	/**
	 * ArrayList of posibly root values
	 */
	private int[] rootsValues = new int[100];
	
	/**
	 * Attribute boolean that define if the polynomial has an independent term.
	 */
	private boolean hasIndependent;
	
	/**
	 * ArrayList of the coefficients of the polynomials.
	 */
	private int[] coefficients;
	
	/**
	 * Attribute boolean that defines if the ruffini technique was implemented to found the root.
	 */
	private boolean ruffini;
	/**
	 * Attribute boolean that defines if the alternative technique was implemented to found the root.
	 */
	private boolean noIndependents;
	/**
	 * Attribute boolean that defines if the alternative technique was implemented to found the root.
	 */
	private boolean sumOfCoeff;
	/**
	 * Arraylist of String that contains the name of the technique and the roots.
	 */
	private String[] values = new String[2];
	
	public Roots() {
		
	}
	
	/**
	 * This method evaluate the coefficients of the polynomial.
	 * @param a coefficients of the polynomials.
	 * @return String of values, that contains the name of the technique and the roots.
	 */
	public String[] evaluation(int[] a) {
		coefficients = a;
		values[0] = "";
		values[1] = "";
		if(a[0] == 0) {
			noIndependents = true;
			values[0] = " M�todo alternativo Ra�ces evidentes. ";
			values[1] = " Como no posee t�rmino independiente la ra�z es igual a 0.";
		}
		
		else {
			int sum = 0;
			for(int i = 0; i<a.length; i++) {
				sum += a[i];
			}

				if( a.length == 2) {
					values[0] = " M�todo de despeje para polinomios de grado 1";
					values[1] ="" + (double)( coefficients[0] / coefficients[1]);
				}
				if(a.length == 3) {
					values[0] = " M�todo f�rmula cuadr�tica.";
					values[1] = cuadratic();
				}
				if(a.length > 3) {
				values[0] = " M�todo de Ruffini. ";
				values[1] = ruffini(a[0]);
				}

		}
		return values;
	}
	
	
	/**
	 * This method defines the cuadratic technique to found roots for second grade polynomials.
	 * @return ArrayList of String, that contains the name of the technique and the roots.
	 */
	public String cuadratic() {
		String valu = "";
		double b = coefficients[1]* -1;
		double a = coefficients[2];
		double c = coefficients[0];
		double aux = (Math.pow(b, 2)- 4*(a*c));
		if((aux)<0) {
			valu += " El polinomio posee raices imaginarias.";
		}
		else {
			DecimalFormat df = new DecimalFormat("#.##");
			df.setRoundingMode(RoundingMode.CEILING);
			double f =(b + Math.sqrt(aux))/(2*a);
			double h =(b - Math.sqrt(aux))/(2*a);
			
			valu += "("+ df.format(f) + ") ";
			valu += "("+df.format(h)+")";
		}
		return valu;
		
	}
	/**
	 * This method define the ruffini technique to found roots.
	 * @param a the coefficients of the polynomials.
	 * @return ArrayList String, that contains the name of techniques and the roots.
	 */
	public String ruffini(int a) {
		String values = "";
		int auxiliarOperation[] = null;
		auxiliarOperation = foundDivisors(a);
		
		if(auxiliarOperation != null) {
			for(int i = 0; i< auxiliarOperation.length; i++) {
				int result = 100;
				
			for(int j = coefficients.length-1; j>0; j--) {
				
			if( j == coefficients.length -1) {
				result = coefficients[j];
			}
			else {
				result = (result * auxiliarOperation[i]) + coefficients[j-1];
			}
			}
			if(result == 0){
				values += auxiliarOperation[i] + "  ";
				}
			}
			if(values == "") {
				values = " No se encontraron ra�ces para el polinomio. ";
			}
		}
		return values;
	}
	
	/**
	 * Auxiliar methos of the ruffini method.
	 * @param a
	 */
	public void auxiliarRuffini(int a) {
		for(int i = 1; i< coefficients.length; i++) {
			
		}
	}
	/**
	 * This method found the divisors of the independent term, its useful for the ruffini method.
	 * @param a integer that represents the independent term.
	 * @return ArrayList of divisors.
	 */
	public int[] foundDivisors(int a) {
		int counter = 0;
		int j = 0;
		boolean stop = false;
		int[] ret = null;
		if( a<0) {
			int n = a * -1;
			int[] auxiliarDivisors = new int[2*n];
			for(int i = a; i<= n; i++) {
				if(i != 0 && a%i == 0) {
					auxiliarDivisors[j] = i;
					
					j++;
				}
			}
			if(j>0) {
				ret = new int[j];
				
				for(int y = 0; y< j; y++) {
					
				
				ret[y] = auxiliarDivisors[y];
		
				}
			}
		
		
		}
		else {
		
				int n = a * -1;
				int[] auxiliarDivisors = new int[2*a];
				for(int i = n; i<= a; i++) {
					if(i != 0 && a%i == 0) {
						auxiliarDivisors[j] = i;
						
						j++;
					}
				}
				if(j>0) {
					ret = new int[j];
					
					for(int y = 0; y< j; y++) {
						
					
					ret[y] = auxiliarDivisors[y];
					}
			
				}
			
			
			
		}
	
		return ret;
		
	}
	
	

}
