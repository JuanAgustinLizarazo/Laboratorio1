package AlertsP;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

/**
 * This class show the user errors, information, suggestions.
 * @author Juan Agust�n Lizarazo
 *
 */
public class AlertPolynomials extends Alert{
	

	/**
	 * Constant that defines the message for an error.
	 */
	
	private static final char ERROR = 'E';
	
	/**
	 * Constant that defines the message for information
	 */
	
	private static final char INFORMATION = 'I';

	
	public AlertPolynomials(AlertType alertType, String mensaje) {
		super(alertType);
		
		
		if(alertType == AlertType.ERROR) {
			
			setTitle("Error");
			
			setHeaderText("La causa del error es: "+ mensaje);
		}
		
		if(alertType == AlertType.INFORMATION) {
			
			setTitle("Informaci�n");
			
			setHeaderText("Se informa al usuario que: "+mensaje);
		}
		// TODO Auto-generated constructor stub
	}


}
